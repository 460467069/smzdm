//
//  ZZHomeViewController.h
//  什么值得买
//
//  Created by Wang_ruzhou on 16/8/12.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZZFirstTableViewController.h"

@interface ZZHomeViewController : ZZFirstTableViewController

@end
