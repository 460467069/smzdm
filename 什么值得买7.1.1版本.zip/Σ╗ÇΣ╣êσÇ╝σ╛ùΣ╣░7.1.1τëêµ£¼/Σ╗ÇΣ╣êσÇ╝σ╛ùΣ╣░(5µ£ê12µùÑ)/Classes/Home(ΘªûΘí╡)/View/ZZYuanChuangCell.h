//
//  ZZYuanChuangCell.h
//  什么值得买
//
//  Created by Wang_ruzhou on 16/8/16.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZZWorthyArticle.h"

@interface ZZYuanChuangCell : UITableViewCell

/** 模型 */
@property (nonatomic, strong) ZZWorthyArticle *article;

@end
