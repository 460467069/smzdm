//
//  ZZDetailHuaTiBottomBar.h
//  什么值得买
//
//  Created by Wang_ruzhou on 16/9/15.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import "ZZDetailBaseBottomBar.h"

@interface ZZDetailHuaTiBottomBar : ZZDetailBaseBottomBar

@end
