//
//  ZZBaiCaiHeaderView.swift
//  什么值得买
//
//  Created by Wang_ruzhou on 2016/11/23.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

import UIKit


class ZZBaiCaiBannerView: UIView {
    @IBOutlet weak var titleLabel: UILabel!

    @IBOutlet weak var accessoryBtn: UIButton!
}
