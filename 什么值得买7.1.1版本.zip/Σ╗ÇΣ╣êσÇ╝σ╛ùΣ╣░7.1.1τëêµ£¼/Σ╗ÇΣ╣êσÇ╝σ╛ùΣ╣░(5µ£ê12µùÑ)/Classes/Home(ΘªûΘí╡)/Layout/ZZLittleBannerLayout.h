//
//  ZZLittleBannerLayout.h
//  什么值得买
//
//  Created by Wang_ruzhou on 2016/11/2.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kLitterBannerViewInset 15

@interface ZZLittleBannerLayout : UICollectionViewFlowLayout

@end
