//
//  ZZTableView.h
//  什么值得买
//
//  Created by Wang_ruzhou on 16/6/13.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZZWeiboTableView : UITableView

@end
