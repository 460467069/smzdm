//
//  ZZMiaoShaCell.swift
//  什么值得买
//
//  Created by Wang_ruzhou on 2017/1/2.
//  Copyright © 2017年 Wang_ruzhou. All rights reserved.
//

import UIKit

class ZZMiaoShaCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
