//
//  ZZLittleBanner.m
//  什么值得买
//
//  Created by Wang_ruzhou on 16/8/8.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import "ZZLittleBanner.h"

@implementation ZZLittleBanner

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"redirectData"  : @"redirect_data"};
}

@end
