//
//  ZZRedirect_Data.h
//  什么值得买(5月12日)
//
//  Created by Wang_ruzhou on 16/5/17.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZZRedirectData : NSObject
@property (nonatomic, copy) NSString *link_type;

@property (nonatomic, copy) NSString *link_val;

@property (nonatomic, copy) NSString *sub_type;

@property (nonatomic, copy) NSString *link_title;

@property (nonatomic, copy) NSString *link;

@property (nonatomic, copy) NSString *isv_code_second;

@property (nonatomic, copy) NSString *channelID;

@end
