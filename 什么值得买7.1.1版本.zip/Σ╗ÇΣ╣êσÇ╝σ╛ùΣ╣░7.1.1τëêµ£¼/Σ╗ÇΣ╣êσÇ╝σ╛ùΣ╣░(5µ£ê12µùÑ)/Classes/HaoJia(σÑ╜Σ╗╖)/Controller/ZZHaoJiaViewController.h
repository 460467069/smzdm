//
//  ZZHomeViewController.h
//  什么值得买(5月12日)
//
//  Created by Wang_ruzhou on 16/5/12.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZZFirstBaseViewController.h"

@interface ZZHaoJiaViewController : ZZFirstBaseViewController

@end
