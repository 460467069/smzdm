//
//  ZZHomeHeaderViewController.m
//  什么值得买
//
//  Created by Wang_ruzhou on 16/9/15.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import "ZZHaoJiaHeaderViewController.h"

@interface ZZHaoJiaHeaderViewController ()

@end

@implementation ZZHaoJiaHeaderViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
