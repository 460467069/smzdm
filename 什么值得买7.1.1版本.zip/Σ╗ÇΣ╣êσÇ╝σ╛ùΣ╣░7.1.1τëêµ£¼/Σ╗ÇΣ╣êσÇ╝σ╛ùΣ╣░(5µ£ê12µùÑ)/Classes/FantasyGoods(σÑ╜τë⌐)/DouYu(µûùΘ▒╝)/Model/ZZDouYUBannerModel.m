//
//  ZZDouYUBannerModel.m
//  什么值得买
//
//  Created by Wang_ruzhou on 16/7/14.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import "ZZDouYUBannerModel.h"

@implementation ZZDouYUBannerModel



@end


@implementation ZZDouYuRoom


+ (NSDictionary *)mj_objectClassInArray{
    return @{@"cdnsWithName" : [ZZDouYuCdnswithname class]};
}

@end

@implementation ZZDouYuCdnswithname



@end