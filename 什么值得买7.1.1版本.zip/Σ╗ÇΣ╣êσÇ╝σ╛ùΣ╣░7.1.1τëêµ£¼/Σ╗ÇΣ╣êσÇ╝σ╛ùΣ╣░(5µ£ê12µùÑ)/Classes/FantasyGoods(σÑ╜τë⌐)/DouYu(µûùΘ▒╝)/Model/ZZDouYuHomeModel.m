//
//  ZZDouYuHomeModel.m
//  什么值得买
//
//  Created by Wang_ruzhou on 16/7/15.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import "ZZDouYuHomeModel.h"

@implementation ZZDouYuHomeModel


+ (NSDictionary *)mj_objectClassInArray{
    return @{@"room_list" : [ZZDouYURoom_List class]};
}
@end

@implementation ZZDouYURoom_List

@end


