//
//  ZZPureWebViewController.h
//  什么值得买
//
//  Created by Wang_ruzhou on 2016/11/2.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import "ZZSecondBaseViewController.h"
#import "ZZWorthyArticle.h"

@interface ZZPureWebViewController : ZZSecondBaseViewController

@property (nonatomic, strong) ZZRedirectData *redirectdata;


@end
