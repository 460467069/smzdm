//
//  ZZJingXuanModel.h
//  什么值得买
//
//  Created by Wang_ruzhou on 16/8/31.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZZJingXuanModel : NSObject

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *destinationVC;

+ (NSArray *)models;

@end
