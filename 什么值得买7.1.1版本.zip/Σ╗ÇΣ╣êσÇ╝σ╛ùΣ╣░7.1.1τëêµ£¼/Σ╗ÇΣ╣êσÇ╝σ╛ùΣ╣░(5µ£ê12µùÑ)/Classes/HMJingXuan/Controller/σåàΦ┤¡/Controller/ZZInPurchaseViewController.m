//
//  ZZInPurchaseViewController.m
//  什么值得买
//
//  Created by Wang_ruzhou on 16/9/2.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import "ZZInPurchaseViewController.h"

@interface ZZInPurchaseViewController ()

@end

@implementation ZZInPurchaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

@end
