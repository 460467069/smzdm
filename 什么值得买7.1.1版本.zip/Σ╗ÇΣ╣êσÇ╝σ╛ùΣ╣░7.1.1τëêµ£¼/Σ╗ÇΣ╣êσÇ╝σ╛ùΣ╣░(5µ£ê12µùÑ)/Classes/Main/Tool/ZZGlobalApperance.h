//
//  ZZGlobalApperance.h
//  什么值得买
//
//  Created by Wang_ruzhou on 16/7/24.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZZGlobalApperance : NSObject
/** 全局定制 */
+ (void)configureGlobalApperance;

@end
