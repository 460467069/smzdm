//
//  CDCommunityHelper.h
//  BusOnline
//
//  Created by HuangKai on 16/8/3.
//  Copyright © 2016年 Goome. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <YYKit/YYKit.h>

@interface ZZCyclePicHelper : NSObject
/// 圆角头像的 manager
+ (YYWebImageManager *)avatarImageManager;
@end
