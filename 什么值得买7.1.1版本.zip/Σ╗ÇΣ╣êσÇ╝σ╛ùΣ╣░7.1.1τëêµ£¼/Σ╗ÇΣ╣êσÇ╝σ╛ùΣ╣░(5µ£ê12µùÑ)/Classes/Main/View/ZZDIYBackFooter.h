//
//  ZZDIYBackFooter.h
//  什么值得买
//
//  Created by Wang_ruzhou on 16/8/15.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface ZZDIYBackFooter : MJRefreshBackFooter

@end
