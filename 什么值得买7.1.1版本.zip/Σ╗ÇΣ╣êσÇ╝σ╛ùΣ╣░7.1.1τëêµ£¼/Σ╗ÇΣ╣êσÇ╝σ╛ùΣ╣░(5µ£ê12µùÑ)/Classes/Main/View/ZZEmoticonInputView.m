//
//  ZZEmoticonInputView.m
//  什么值得买
//
//  Created by Wang_ruzhou on 2016/11/16.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import "ZZEmoticonInputView.h"

#define kToolbarHeight 37
#define kViewHeight (216 - kToolbarHeight)
#define kOneEmoticonHeight 50
#define kOnePageCount 20

@implementation ZZEmoticonInputView



@end
