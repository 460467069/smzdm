//
//  ZZCycleScrollView.h
//  什么值得买
//
//  Created by Wang_ruzhou on 16/8/13.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import <SDCycleScrollView/SDCycleScrollView.h>

@interface ZZCycleScrollView : SDCycleScrollView

@end
