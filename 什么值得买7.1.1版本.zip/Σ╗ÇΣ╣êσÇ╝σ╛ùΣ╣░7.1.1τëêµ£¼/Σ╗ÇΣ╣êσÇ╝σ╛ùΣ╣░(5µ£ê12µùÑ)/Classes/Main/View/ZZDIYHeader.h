//
//  MJDIYHeader.h
//  MJRefreshExample
//
//  Created by Wang_ruzhou on 16/8/10.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import "MJRefresh.h"

@interface ZZDIYHeader : MJRefreshHeader



@end
