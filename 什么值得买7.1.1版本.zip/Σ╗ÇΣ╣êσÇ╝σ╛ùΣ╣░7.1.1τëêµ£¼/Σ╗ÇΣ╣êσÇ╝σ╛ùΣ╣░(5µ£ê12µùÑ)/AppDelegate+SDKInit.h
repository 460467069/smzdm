//
//  AppDelegate+SDKInit.h
//  什么值得买
//
//  Created by Wang_ruzhou on 2016/11/1.
//  Copyright © 2016年 Wang_ruzhou. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (SDKInit)

- (void)SDKInit;

@end
